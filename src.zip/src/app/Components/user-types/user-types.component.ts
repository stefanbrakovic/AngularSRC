import { Component, OnInit } from '@angular/core';
import {UserTypeService} from "../../Services/user-type.service";

@Component({
  selector: 'app-user-types',
  templateUrl: './user-types.component.html',
  styleUrls: ['./user-types.component.css']
})
export class UserTypesComponent implements OnInit {

  constructor(private userTypeService : UserTypeService) { }

  ngOnInit() {
  }


}
