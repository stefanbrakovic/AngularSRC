import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-genders',
  templateUrl: './genders.component.html',
  styleUrls: ['./genders.component.css']
})
export class GendersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
