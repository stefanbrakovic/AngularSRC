import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-price',
  templateUrl: './service-price.component.html',
  styleUrls: ['./service-price.component.css']
})
export class ServicePriceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
