import { Component, OnInit } from '@angular/core';
import { UserService } from '../../Services/user.service';
import { User} from '../../Models/Users/User';
import {forEach} from "@angular/router/src/utils/collection";
import {FormGroup, FormControl} from "@angular/forms"

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit
{
  form;
  constructor(private _usersService : UserService ){ }
  users : User[];
  ngOnInit(){
    this.form = new FormGroup({
      firstName: new FormControl(""),
      lastName: new FormControl("")
    })
  };
  getAllUsers()
  {
    debugger;
    this._usersService.getAllUsers().subscribe(
      data =>  this.users =data,
      error => alert(error),
      () => console.log("Finished")
    );
  };

  createNewUser(user)
  {
    console.log(user);
  }



}
/*
const asd : User[] =
  [{"userId":1,"firstName":"asd","lastName":"asd","telephone":"123","mail":"asd@1asd","userPassword":"123","userTypeId":7,"genderId":1,"dateOfBirth":"2001-05-31T00:00:00","dateOfRegistration":"2017-05-31T01:05:04.053","street":"sad","city":"asd","streetNumber":"12","provides":[],"subscribed":[],"uses":[]},{"userId":14,"firstName":"asd","lastName":"asd","telephone":"123","mail":"asd@1ashd","userPassword":"123","userTypeId":7,"genderId":1,"dateOfBirth":"2001-05-31T00:00:00","dateOfRegistration":"2017-05-31T01:56:07.887","street":"sad","city":"asd","streetNumber":"12","provides":[],"subscribed":[],"uses":[]},{"userId":16,"firstName":"asd","lastName":"asd","telephone":"123","mail":"asd@1ashdf","userPassword":"123","userTypeId":7,"genderId":1,"dateOfBirth":"2001-05-31T00:00:00","dateOfRegistration":"2017-06-07T09:40:58.007","street":"sad","city":"asd","streetNumber":"12","provides":[],"subscribed":[],"uses":[]}];

const heroes : User[] =
 [{"userId":1,
   "firstName":"asd",
   "lastName":"asd",
   "telephone":"123",
   "mail":"asd@1asd",
   "userPassword":"123",
   "userTypeId":7,
   "genderId":1,
   "dateOfBirth":"2001-05-31T00:00:00",
   "dateOfRegistration":"2017-05-31T01:05:04.053",
   "street":"sad",
   "city":"asd",
   "streetNumber":"12",
   "provides":[],"subscribed": [],"uses":[]},
   {"userId":1,
     "firstName":"asd",
     "lastName":"asd",
     "telephone":"123",
     "mail":"asd@1asd",
     "userPassword":"123",
     "userTypeId":7,
     "genderId":1,
     "dateOfBirth":"2001-05-31T00:00:00",
     "dateOfRegistration":"2017-05-31T01:05:04.053",
     "street":"sad",
     "city":"asd",
     "streetNumber":"12",
     "provides": [],
     "subscribed": [],
     "uses":[]}];
*/
export class Hero {
  id: number;
  name: string;
}
