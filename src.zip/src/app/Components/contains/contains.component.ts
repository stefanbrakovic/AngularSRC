import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contains',
  templateUrl: './contains.component.html',
  styleUrls: ['./contains.component.css']
})
export class ContainsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
