import {Provides} from "../Provides/Provides";
import {ServicePrice} from "../ServicePrice/ServicePrice";
/**
 * Created by OMA on 17-Jun-17.
 */
export class Services
{
  ServicesId : number;
  ServiceName : string;
  ServiceDescription : string;
  IsActive: boolean;
  DateCreated : Date;

  Provides : Array<Provides>;
  ServicePrice : Array<ServicePrice>;

}
