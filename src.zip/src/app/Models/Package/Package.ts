import {Subscribed} from "../Subscribed/Subscribed";
/**
 * Created by OMA on 20-Jun-17.
 */

export class Package
{
  PackageId : number;
  PackageName: string;
  PackageDescription : string;
  IsActive : boolean;
  DateCreated : Date;

  Subscribed : Array<Subscribed>;
}
