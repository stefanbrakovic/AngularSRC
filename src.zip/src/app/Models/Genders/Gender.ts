

export class Gender
{
  GenderId : Number;
  Gender : String;


  constructor(GenderId: Number, Gender: String) {
    this.GenderId = GenderId;
    this.Gender = Gender;
  }
}
