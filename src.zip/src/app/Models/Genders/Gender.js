"use strict";
var Gender = (function () {
    function Gender() {
    }
    return Gender;
}());
exports.Gender = Gender;
//# sourceMappingURL=Gender.js.map