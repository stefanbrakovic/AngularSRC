

export class UserType
{

    UserTypeId : number;
    TypeName : String;
    TypeDescription : String;


  constructor(UserTypeId: number, TypeName: String, TypeDescription: String) {
    this.UserTypeId = UserTypeId;
    this.TypeName = TypeName;
    this.TypeDescription = TypeDescription;
  }
}
