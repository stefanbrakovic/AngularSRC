"use strict";
var UserType = (function () {
    function UserType() {
    }
    return UserType;
}());
exports.UserType = UserType;
//# sourceMappingURL=UserTypes.js.map