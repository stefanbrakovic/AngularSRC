import {Services} from "../Services/Services";
/**
 * Created by OMA on 17-Jun-17.
 */
export class ServicePrice
{
  ServiceId : number;
  DateModified : Date;
  Price : number;
  PriceId : number;

  Service : Services;

}
