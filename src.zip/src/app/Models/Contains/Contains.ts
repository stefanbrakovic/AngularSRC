/**
 * Created by OMA on 17-Jun-17.
 */
export class Contains
{
  ContainsId : number;
  DateAdded : Date;
  Discount : number;
  ServiceId: number;
  PackageId : number;

}
