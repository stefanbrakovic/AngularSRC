import { Injectable } from '@angular/core';
import {Http} from "@angular/http";
import '../../../node_modules/rxjs/add/operator/map'
import {environment} from "../../environments/environment";
import {User} from "../Models/Users/User";

@Injectable()
export class UserService {

  constructor(private _http: Http) { }



  getAllUsers()
  {

    //debugger;
    return this._http.get(environment.apiUrl+'Users')
      .map(res => res.json());

  }
  getUserByCardNumber(cardNumber:string)
  {

    //debugger;
    return this._http.get(environment.apiUrl+'Users/'+cardNumber)
      .map(res => res.json());

  }
  CreateNewUser(user:User)
  {
      return this._http.post(environment.apiUrl+"Users",user);
  }
}
