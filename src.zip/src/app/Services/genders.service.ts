import { Injectable } from '@angular/core';
import {Http} from "@angular/http";
import {environment} from "../../environments/environment";

@Injectable()
export class GendersService {

  constructor(private _http : Http) { }

  getAllGenders()
  {
    return this._http.get(environment.apiUrl+"Genders").map(res=>res.json())
  }


}
