import { Injectable } from '@angular/core';
import {Http} from "@angular/http";
import {environment} from "../../environments/environment";

@Injectable()
export class ServicesService {

  constructor(private _http : Http) { }

  getAllServices()
  {
    return this._http.get(environment.apiUrl+"Services").map(res=>res.json())
  }

  getServiceById(serviceName:string)
  {
    return this._http.get(environment.apiUrl+"Services/"+serviceName).map(res=>res.json())
  }

}
