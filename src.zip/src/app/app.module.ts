import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { UsersComponent } from './Components/users/users.component';
import { UserTypesComponent } from './Components/user-types/user-types.component';
import { GendersComponent } from './Components/genders/genders.component';

import {UserService} from './Services/user.service';
import {HttpModule} from "@angular/http";
import { PackageComponent } from './Components/package/package/package.component';
import { ServiceComponent } from './Components/service/service.component';
import { ServicePriceComponent } from './Components/service-price/service-price.component';
import { UsageComponent } from './Components/usage/usage.component';
import { SubscriptionComponent } from './Components/subscription/subscription.component';
import { ContainsComponent } from './Components/contains/contains.component';
import { LogInComponent } from './Components/log-in/log-in.component';
import { RegisterComponent } from './Components/register/register.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {UserTypeService} from "./Services/user-type.service";
import {GendersService} from "./Services/genders.service";
import {ServicesService} from "./Services/services.service";


@NgModule({
  declarations: [
    AppComponent,
    UsersComponent,
    UserTypesComponent,
    GendersComponent,
    PackageComponent,
    ServiceComponent,
    ServicePriceComponent,
    UsageComponent,
    SubscriptionComponent,
    ContainsComponent,
    LogInComponent,
    RegisterComponent,

  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpModule
  ],
  providers: [UserService,UserTypeService, GendersService, ServicesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
